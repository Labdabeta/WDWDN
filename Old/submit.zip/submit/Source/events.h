#ifndef WDWDN_EVENTS_H
#define WDWDN_EVENTS_H 0.1

void loadEvents(void);
void iteratePortals(void);
int loadNextEvent(int,int,int);
void drawEvents(void);
void cleanEvents(void);

#endif // WDWDN_EVENTS_H
